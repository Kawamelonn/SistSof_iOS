//
//  Importfiles.swift
//  SEL4C
//
//  Created by Andrea Samantha Aguilar on 02/10/23.
//

import SwiftUI

enum ArchivoType: Identifiable {
    case foto,archivo,imagen
    var id: Int {
        hashValue
    }
}

//struct ArchivoView: View {
    
//}
